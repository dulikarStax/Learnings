class Apify:

    def send_input(self):
        pass

    def convert_json_tabular(self):
        pass

class Database:

    def save_result(self):
        pass


class Process:

    def add_sentiment(self):
        pass

    def add_topic_id(self):
        pass

    def add_topic_names(self):
        pass

