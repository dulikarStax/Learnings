#https://docs.apify.com/tutorials/integrations/run-actor-and-retrieve-data-via-api#wait-for-the-run-to-finish

from apify_client import ApifyClient

# Initialize the ApifyClient with your API token
client = ApifyClient("apify_api_DnaczSnE3DZIUaQzCTvCG62MphzHoi3a8k3x")

# Prepare the actor input
run_input = {
    "searchStringsArray": ["restaurant New York"],
    "maxCrawledPlaces": 3,
    "maxCrawledPlacesPerSearch": 3,
    "language": "en",
    "maxImages": 0,
    "maxReviews": 0,
    "proxyConfig": { "useApifyProxy": True },
    "allPlacesNoSearchAction": "",
}

# Run the actor and wait for it to finish
run = client.actor("drobnikj/crawler-google-places").call(run_input=run_input)

# Fetch and print actor results from the run's dataset (if there are any)
for item in client.dataset(run["defaultDatasetId"]).iterate_items():
    print(item)