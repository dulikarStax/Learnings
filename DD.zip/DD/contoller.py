
class UserOperator:

    def load_inpu(self):
        pass

    def send_topics(self):
        pass

    def recieve_topics(self):
        pass

    def output(self):
        pass


class Topics:

    def get_topics(self):
        pass

    def set_topics(self):
        pass